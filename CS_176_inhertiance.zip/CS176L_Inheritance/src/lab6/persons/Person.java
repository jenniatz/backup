package lab6.persons;
/**
 * define the person superclass
 * @author jenni A.
 *
 */
public class Person {

	//data 
	private String name;
	
	//methods 
	/**
	 * set person's name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	/**
	 * return the person's class and name 
	 * @return person data
	 */
	public String toString() {
		
		//complete this code
		
		
		return getClass() + "\nName: " + this.name;
		
		
		
	}
	
}
