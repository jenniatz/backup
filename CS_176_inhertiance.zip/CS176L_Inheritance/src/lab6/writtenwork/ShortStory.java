package lab6.writtenwork;

public class ShortStory extends WrittenWork{

	private String genre;
	private int paragraphs;
	private boolean hasPics;
	
	
	public ShortStory (String title, String author, int year, String genre, int paragraphs, boolean hasPics) {
        
    	

		super(title, author, year);
		setGenre(genre);
		setParagraphs(paragraphs);
		setIllustrated(hasPics);
		
		
	       
    }

	
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getParagraphs() {
		return paragraphs;
	}
	public void setParagraphs(int paragraphs) {
		this.paragraphs = paragraphs;
	}
	//set haspics to boolean
	public boolean getIllustrated() {
		return hasPics;
	}
	public void setIllustrated(boolean hasPics) {
		this.hasPics = hasPics;
	}
	
	public String toString() {
		String s = super.toString();
		return "ShortStory " + "\n" +  s + "\n" + "Genre = "+ getGenre() + "\n" + "Paragraphs = " 
				+ getParagraphs() +"\n"+"Has Pictures = " 
				+ getIllustrated();
	}
	
	
	
}
