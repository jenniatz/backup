package lab6.writtenwork;

public class TestWrittenWorks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Novel novel = new Novel("Harry Potter and the Sorcerer's Stone ", "J.K Rowling" , 1997, "Fanasty Fiction ", 17);
		System.out.println(novel);
		
		System.out.println();
		ShortStory shortstory = new ShortStory ("The Gift of the Magi" , "O. Henry ", 1905, "Fiction ", 39, false );
		
		System.out.println(shortstory);
		
		
		
		
	}

}
