 package lab6.writtenwork;

public class Novel extends WrittenWork {
	 private String genre;
	    private int chapters;

	    // constructors:
	    public Novel(String title, String author, int year, String genre, int chapters) {
	        /* _________Line 11_________ */
	    	//call super class 
	    	super(title, author, year);
	        setGenre( genre );
	       setChapters( chapters );
	    }

		
	    // accessor methods:
	    /** 
	        Write the getGenre method.
	        @return genre of Novel
	    */

	    public String getGenre() {
	    	return genre;
	    }

	    
	   
	    /**
	        Write the getChapters method.
	        @return number of Novel chapters
	    */

	    public Integer getChapters() {
	    	return chapters;
	    }

	    /**
	        Write the setGenre method.
	        @param Novel's genre
	    */

	    public void setGenre(String genre) {
	    	this.genre = genre;
	    }


	    /**
	        Write the setChapters method.
	        @param Number of Novel chapters
	    */

	    public void setChapters(int chapter) {
	    	this.chapters = chapter;
	    }

	    public String toString() {
	    	String s = super.toString();
	    	return "Novel " + "\n" + s + "\n" + "Genre = " + getGenre()+ "\n" + "Chapters = " + getChapters();
	    }

}
