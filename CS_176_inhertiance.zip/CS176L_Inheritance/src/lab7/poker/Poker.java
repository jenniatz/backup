package lab7.poker;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Your name: Jenni A.
 *
 * Poker.java: Contains a deck of PlayingCards and methods to play basic poker
 *
 */


public class Poker extends CardGame{
	// Constructor(s):	
	

		public Poker()
		{
	      super(true); //calls superclass card game constuctor with shuffle = true
		} // end constructor



		// Methods:
		
		
		// Methods to detect hand ranks:
		
		/*
		 * Return the number of pairs:
		 * 0 = no pairs, 1 = one pair, 2 = two pairs
		 * @param hand of 5 PlayingCards 
		 * @return number of pairs in hand 
		 */
		
		
		
		
		//hand is always gonna have 5 cards 
		public int getPairs(PlayingCard [] hand)
		{
			
			int checkForPairs = 0;
			for(int counter = 1; counter < 5; counter++)
			{
				if (hand[counter - 1] == hand[counter])
				{
					checkForPairs++;
				}
			}
			if (checkForPairs == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}	
	       // dummy value 		
		} // end getPair()
		
		public int getTwoPairs(PlayingCard [] hand)
		{	
			
			int check = 0;
			for(int counter = 1; counter < 5; counter++)
			{
				if (hand[counter - 1] == hand[counter])
				{
					check++;
				}
			}
			if (check == 2)
			{
				return 1;
			}
			else
			{
				return 0;
			}
			
		}
		/**
		 * Detect Three of a kind.  
		 * @param hand of 5 playing cards 
		 * @return three of a kind, true or false 
		 */
		public boolean hasThreeOfAKind(PlayingCard [] hand)
		{    	
			for (int i=0;i<hand.length;i++) {
			boolean hasPair = false;
				for (int j=0;j<hand.length;j++) {
					if (hand[i] != hand[j] && hand[i].getValue() == hand[j].getValue()) {
						if (!hasPair) {
							hasPair = true;
						} else {
							return true;
						}
					}
				}
			}
			return false;	
			
	       // dummy value		
		} // end hasThreeOfAKind
		
		
		
		
		/**
		 * Detect Full House
		 * 
		 */
		public boolean hasFullHouse(PlayingCard [] hand)
		{
			int comparison = 0;
			for (int counter = 1; counter < 5; counter++)
			{
				if (hand[counter - 1] == hand[counter])
				{
					comparison++;
				}
			}
			if (comparison == 3)
			{
				return true;
			}
			else
			{
				return false;
			}
		
	       // dummy val		
		} // end hasFullHouse

		

		
		/**
		 * Detect Four of a Kind.
		 */
		public boolean hasFourOfAKind(PlayingCard [] hand)
		{   
			
				return false;
			
			
	      // dummy val		
		} // end hasFourOfAKind	
		
		
		
		/**
		 * Detect Flush.
		 */
		public boolean hasFlush(PlayingCard [] hand)
		{    		
				
	      return false; // dummy val		
		} // end hasFlush
		
		
		
		
		/**
		 * Detect a Straight (INCOMPLETE)
		 */
		public boolean hasStraight(PlayingCard [] hand)
		{
			return hand[4].getValue() - hand[0].getValue() == 4;	
	       // dummy val		
		} // end hasStraight
			
		
		
		/**
		 * Detect a Straight Flush
		 */
		public boolean hasStraightFlush(PlayingCard [] hand)
		{
			return false;
			
	       // dummy val		
		} // end hasStraightFlush
		
		
		
		/**
		 * Detect a Royal Flush
		 */
		public boolean hasRoyalFlush(PlayingCard [] hand)
		{
			
				return false;
			
					
	      // dummy val		
		} // end hasRoyalFlush
		

}
