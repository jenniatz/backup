/**
 * @author Jenni A.
 */
package lab7.poker;

import java.util.Arrays;

public class PlayPoker {
	
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		Poker poker = new Poker();
		
		
			// makes a hand (for TA; testing purposes)
				// Your code here
		PlayingCard[] hand = new PlayingCard[5];
		for ( int i = 0; i<5; i++) {
			hand[i] = poker.draw();
		
		}
	
				//String grade = "This method should evaluate the hand and return the grade i.e. One pair, Two pairs, Three of a kind, etc.";
				// return grade;
			if (poker.hasThreeOfAKind(hand) == true) {
			 System.out.println("Three of a kind");
		 }
		
			else if (poker.getTwoPairs(hand) == 1)
			{
				System.out.println("Two Pairs");
			}
			else if (poker.getPairs(hand) == 1)
			{
				System.out.println("Pair");
			}
			else
			{
				
			}
			
		
		//? The value to use if the condition is true
		//: The value to use if the condition is false
		System.out.print("Here is your hand: ");
		System.out.println();
		for (int i=0;i<hand.length;i++) {
			System.out.println();
			System.out.print(hand[i].toString()
					 +(i+1 == hand.length ? "  " : "  " + ""));
			
		}
	
		

		System.out.println();
		int pairs = poker.getPairs(hand);
		int twoPairs = poker.getTwoPairs(hand);
		if (poker.hasThreeOfAKind(hand) == true) {
			System.out.println("3");
		} else if (poker.getPairs(hand) > 0) {
			System.out.println("Your have "+ pairs+" pair");
			
		} 
		else if (poker.getTwoPairs(hand) >0) {
			System.out.println("2 pairs" + twoPairs);
		}
		
		else {
			System.out.println("Your deck has no pairs.");
		}
	}

	
		
		
		
	
}
		
	
	
	
	
		
		
		
	
	


        
     
		
		


	
	








		
		//game1.deck
		
//		for ( int i = 0; i<5; i++) {
//			hand[i] = poker.draw();
//			if (i ==3) {
//				hand[1] = hand[i-1];
//			
//			}
//			
//			System.out.println(hand[i]);
//			
//		}
		
		
		
		
	


