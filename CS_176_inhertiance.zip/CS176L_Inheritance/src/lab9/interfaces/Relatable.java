/**
 * @author Jenni A
 */
package lab9.interfaces;

public interface Relatable{
	  	public abstract boolean equals(Triangle o);
	    public abstract boolean lessThan(Triangle o);
	    public abstract boolean greaterThan(Triangle o);

}
