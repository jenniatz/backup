/**
 * @author Jenni A
 */
package lab9.interfaces;

public class TestTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Construct 2 valid Triangle objects triangle1 and triangle2.
		Triangle triangle1 = new Triangle();
		Triangle triangle2 = new Triangle();
		
		//Using methods inherited from GeometricObject1,
		//set triangle1's color to yellow and filled status to true. 
		//Also, set triangle2's color to blue and filled status to false.
		
		triangle1.setColor("yellow");
		triangle1.setFilled(true);
		
		triangle2.setColor("blue");
		triangle2.setFilled(false);
	
		
		//Print all triangle1 and triangle2 data using their toString() methods.

		System.out.println(triangle1.toString());
		System.out.println(triangle2.toString());
		
		System.out.println();
		
		
		
		//Test the 3 methods of the Relatable interface to print whether triangle1 
		//is larger, triangle2 is larger or both triangles are the same size, 
		//based on the areas of the triangles.

		
		
		
		System.out.println(triangle1.greaterThan(triangle2));
		System.out.println(triangle1.equals(triangle2));
		System.out.println(triangle1.lessThan(triangle2));
		
		System.out.println();
		
		System.out.println(triangle2.greaterThan(triangle1));
		System.out.println(triangle2.equals(triangle1));
		System.out.println(triangle2.lessThan(triangle1));
		
		
		
	}

}
