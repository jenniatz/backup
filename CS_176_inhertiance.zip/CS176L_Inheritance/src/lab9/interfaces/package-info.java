package lab9.interfaces;
