/**
 * 
 * Cat subclass of Pet
 * @author jenni a.
 */


package lab8.petstore;

public class Cat extends Pet{
	 // instance vars
	   private String name;
	   private String breed;
	   
	   // constructor
	   public Cat(String name, int age, String breed, boolean adoptable) {
			super("Cat", age, adoptable); // Call Pet superclass constructor
			this.name = name;
			this.breed = breed;
		}
	   

	// methods
	   @Override
	   public String toString() {
	      return super.toString() + "\n" +
	         "Name: " + name + "\n" +
	         "Breed: " + breed;
	   }
	}


