/**
 * Fish subclass of Pet
 * @author jenni a.
 */
package lab8.petstore;

public class Fish extends Pet  {
	// instance vars
	private String type; // "catfish", "goldfish", "shark", etc.
	private String size; // "small", "medium", "large", etc.
	
	public Fish(String type, String size, String name, int age, String breed, boolean adoptable) {
		   super("Fish",age, adoptable);
			this.type = type;
			this.size = size;
		}

	


	   /* Complete the code below: */
	   
	   // constructor (similar to Cat class)

	   

	   // methods (just the toString() method)
	   @Override

	   public String toString() {
		   String s = super.toString();
		   return s + "Type: " + type + "\n"
		   + "Size: " + size;
	   }


	

	


}
