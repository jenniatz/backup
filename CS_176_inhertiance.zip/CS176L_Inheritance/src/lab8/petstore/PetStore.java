/**
 * Represents a pet store that contains a variety of pets.
 * @author jenni a.
 */
package lab8.petstore;

import java.util.ArrayList;
import java.util.Collection;

public class PetStore   {
	
	//instance variables
	   // Complete the code below to create an ArrayList of Pet called pets:
	

	   // Named constants for readability:
	   private final static int ALL = 0;
	   private final static int CAT = 1;
	   private final static int FISH = 2;

	   // no constructor (just use the default)
	private ArrayList<Pet> pets = new ArrayList<Pet>();
	   
	   // methods
	   /**
	    * Complete this code:
	    *
	    * Add a Pet to the pets ArrayList
	    *
	    * @param a Pet object
	    */
	   public void addPet(Pet pet) {
	      
		   
	        pets.add(pet);
	   }
	   
	   
	   public PetStore() {
		   super();
	   }

	   /**
	    * Complete this code:
	    * 
	    * List Pet objects in pets ArrayList.
	    *
	    * Modify the listPets() method to accept an int parameter that represents either CAT or FISH or ALL.
	    * If ALL, list all pets.
	    * If CAT, list only Cats.
	    * If FISH, list only Fish.
	    *
	    * @param int value which is ALL, CAT or FISH
	    */
	   public void listPets(int type) {
	     
		   int count = 1;
	      
	     
	      for (Pet critter : pets) {
	         System.out.println(count + ":\n" + critter); // triggers toString() of critter object
	         count++;
	      }
	   
	   }   
	   
	   public static void main(String[] args) {
	      // Construct a PetStore object
	      PetStore mystore = new PetStore();
	      
	      // Construct and add a number of Cat objects to mystore
	      Cat fuzzy = (new Cat("Fuzzy", 50, "Mix", true));
	      mystore.addPet(fuzzy);
	      mystore.addPet(new Cat("Wuzzy", 90, "Manx", false));

	      // Complete the code below:

	      // Call the listPets method to list all pets:

	      mystore.listPets(ALL);
	      System.out.println("-----------------");
	      // Construct a number of Fish objects and add them to the pets ArrayList, 
	      Fish patrick = new Fish("Salmon", "Medium", "Harry", 2, "no", false);
	      //  and then list all the pets again. 
	      mystore.addPet(patrick);
	      // Call the listPets method to print only Cats.
	      mystore.listPets(CAT);
	      // Call the listPets method to print only Fish.
	      mystore.listPets(FISH);
			
			
			

	   }

}
