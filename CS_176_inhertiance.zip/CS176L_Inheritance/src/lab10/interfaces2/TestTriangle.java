package lab10.interfaces2;

import java.util.ArrayList;

import lab9.interfaces.Triangle;

public class TestTriangle {
	//Create an ArrayList of Triangle objects called 'triangles' 
	//that contains 5 valid Triangle objects.
	
	
//	ArrayList<Triangle> triangles = new ArrayList<Triangle>();
//	
//	lab10.interfaces2.Triangle triangle1 = new Triangle();
//	Triangle triangle2 = new Triangle();
//	
	
	
	
	//Sort the 'triangles' ArrayList using Collections.sort().
		//The triangles must be sorted by area, from smallest to largest area.
	
	
	//Print out the sorted ArrayList of triangles using each Triangle's toString() method.



}
