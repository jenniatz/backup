package lab10.comparablesong;

//TestPlayList.java


public class TestPlayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PlayList mySongs = new PlayList( "My songs" );
	    
        // COMPLETE THIS CODE:
        // Construct at least 3 Songs and add them to the mySongs PlayList.



        // COMPLETE THIS CODE:
        // List all Songs in mySongs.
        


        // COMPLETE THIS CODE:
        // Shuffle the Songs in mySongs and then list them all again.




        // COMPLETE THIS CODE:
        // Use the static Song.setSortBy() method to make Songs sortable by name.
        // Sort the Songs in mySongs, then list them all again. 

 

        // COMPLETE THIS CODE:
        // Use the static Song.setSortBy() method to make Songs sortable by artist.
        // Sort the Songs in mySongs, then list them all again. 
 


        // COMPLETE THIS CODE:
        // Use the static Song.setSortBy() method to make Songs sortable by album.
        // Sort the Songs in mySongs, then list them all again. 



        // COMPLETE THIS CODE:
        // Use the static Song.setSortBy() method to make Songs sortable by genre.
        // Sort the Songs in mySongs, then list them all again. 




	}

} // end class
